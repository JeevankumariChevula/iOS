//
//  ViewController.swift
//  Chevula_Assignment01
//
//  Created by Chevula,Jeevan Kumari on 2/1/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var FNInput: UITextField!
    

    @IBOutlet var LNInput: UITextField!
        
    
    @IBOutlet var dobInput: UITextField!
    
    
    @IBOutlet var DetailsOutlet: UILabel!
    
    @IBOutlet var fullnameOutlet: UILabel!
    
    
    @IBOutlet var intialsOutlet: UILabel!
    
    
    @IBOutlet var ageOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func submitOutlet(_ sender: Any) {
        var firstName = FNInput.text!
        var lastName = LNInput.text!
        var DOB = dobInput.text!
        let mydob = Int(DOB)
        
        // var Details = DetailsOutlet.text!
        DetailsOutlet.text! = "Details"
        fullnameOutlet.text! = " Full Name : \(firstName) \(lastName)"
        intialsOutlet.text! = " Intials : \(firstName.first!) \(lastName.first!)"
        ageOutlet.text! = " Age : \(mydob!)"
        let year = Calendar.current.component(.year, from: Date())
        print(year)
        
    }
    
    
    
    @IBAction func resetOutlet(_ sender: Any) {
        
    }
    
    

}

