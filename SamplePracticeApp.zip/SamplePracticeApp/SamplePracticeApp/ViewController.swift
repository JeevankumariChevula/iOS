//
//  ViewController.swift
//  SamplePracticeApp
//
//  Created by Chevula,Jeevan Kumari on 1/26/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Course1Outlet: UITextField!
    
    @IBOutlet weak var Course2Outlet: UITextField!
    
    @IBOutlet weak var DisplayOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Submit(_ sender: Any) {
    
    // Read the Course1 Name and store it in a variable
    var course1Name = Course1Outlet.text!;
    
    //Read the Course2 Name and store it in a variable
    var course2Name = Course2Outlet.text!;
    
    //Perform string interpolation and assign to dispaly label.(Course1 - Course2)
    
    DisplayOutlet.text = "\(course1Name) - \(course2Name)"
        
}

}

