//
//  ViewController.swift
//  Vowels
//
//  Created by Chevula,Jeevan Kumari on 1/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textOutlet: UITextField!
    

    
    @IBOutlet weak var isvowelOutlet: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func isvowel(_ sender: Any) {
        let myvowel = textOutlet.text!
        if(myvowel.contains("aA") || myvowel.contains("eE") || myvowel.contains("iI") || myvowel.contains("oO") || myvowel.contains("uU"))
        {
            //text vowel is hidden
            isvowelOutlet.text = "The \(myvowel) has vowel 😊"
        }
           else {
            isvowelOutlet.text = "The \(myvowel) has no vowel 🙁"
        }
            
    }
    
}

